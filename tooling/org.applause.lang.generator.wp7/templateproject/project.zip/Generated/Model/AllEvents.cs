﻿using System.Collections.Generic;

namespace ItemisApp.Model
{
    public class AllEvents
    {
        public List<Event> News { get; set; }
        public List<Event> Activity { get; set; }
        public List<Event> Workshop { get; set; }
    }
}
