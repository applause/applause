﻿
namespace ItemisApp.Model
{
    public class Contact
    {
        public string Name { get; set; }
	    public string Role { get; set; }
        public string Bio { get; set; }
	    public string Pictureurl { get; set; }
	    public string Mail { get; set; }
        public string Phone { get; set; }
    }
}
