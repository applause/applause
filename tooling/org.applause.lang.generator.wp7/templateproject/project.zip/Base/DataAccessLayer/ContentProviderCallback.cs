﻿
namespace Applause.DataAccessLayer
{
    public delegate void ContentProviderResultCallback(object result);
}
