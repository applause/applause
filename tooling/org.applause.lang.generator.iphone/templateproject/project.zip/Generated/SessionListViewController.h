
#import <UIKit/UIKit.h>
#import "IPTableViewController.h"

@interface SessionListViewController : IPTableViewController {

}

@end
