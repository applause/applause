
#import <UIKit/UIKit.h>
#import "IPDetailsViewController.h"

@interface SessionDetailsViewController : IPDetailsViewController {

}

@end
