
#import <UIKit/UIKit.h>
#import "IPTableViewController.h"

@interface RepositoryListViewController : IPTableViewController {

}

@end
