
#import <UIKit/UIKit.h>
#import "IPDetailsViewController.h"

@interface SpeakerDetailsViewController : IPDetailsViewController {

}

@end
