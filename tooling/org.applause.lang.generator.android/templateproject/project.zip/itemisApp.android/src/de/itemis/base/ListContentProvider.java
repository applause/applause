package de.itemis.base;

import java.util.List;

public interface ListContentProvider<T> {

	public List<T> getAllItems();
	
}
