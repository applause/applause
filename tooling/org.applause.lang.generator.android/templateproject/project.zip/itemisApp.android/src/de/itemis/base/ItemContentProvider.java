package de.itemis.base;

public interface ItemContentProvider<T> {

	public T getItem();
	
}
